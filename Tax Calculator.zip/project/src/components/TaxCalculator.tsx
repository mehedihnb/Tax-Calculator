import React, { useState, useEffect } from 'react';
import { Calculator } from 'lucide-react';

interface TaxBracket {
  min: number;
  max: number | null;
  rate: number;
  display: string;
}

type TaxPayerCategory = 'male' | 'female' | 'disabled' | 'freedomFighter';

const TAX_BRACKETS: TaxBracket[] = [
  { min: 0, max: 350000, rate: 0, display: 'BDT 0-350,000' },
  { min: 350001, max: 450000, rate: 0.05, display: 'BDT 350,001-450,000' },
  { min: 450001, max: 850000, rate: 0.10, display: 'BDT 450,001-850,000' },
  { min: 850001, max: 1350000, rate: 0.15, display: 'BDT 850,001-1,350,000' },
  { min: 1350001, max: 1850000, rate: 0.20, display: 'BDT 1,350,001-1,850,000' },
  { min: 1850001, max: 3850000, rate: 0.25, display: 'BDT 1,850,001-3,850,000' },
  { min: 3850001, max: null, rate: 0.30, display: 'BDT 3,850,001 and above' },
];

const MINIMUM_TAX = {
  dhaka_chittagong: 5000,
  other_city: 4000,
  rest: 3000,
};

const TaxCalculator: React.FC = () => {
  const [income, setIncome] = useState<number>(0);
  const [category, setCategory] = useState<TaxPayerCategory>('male');
  const [location, setLocation] = useState<'dhaka_chittagong' | 'other_city' | 'rest'>('dhaka_chittagong');
  const [investment, setInvestment] = useState<number>(0);
  const [sourceTax, setSourceTax] = useState<number>(0);
  const [taxableIncome, setTaxableIncome] = useState<number>(0);
  const [totalTax, setTotalTax] = useState<number>(0);
  const [netTaxPayable, setNetTaxPayable] = useState<number>(0);

  const calculateExemptedIncome = (grossIncome: number): number => {
    // Basic exemption based on category
    let basicExemption = category === 'female' || category === 'disabled' ? 400000 : 350000;
    if (category === 'freedomFighter') basicExemption = 475000;
    
    return basicExemption;
  };

  const calculateInvestmentRebate = (investmentAmount: number): number => {
    const maxInvestmentAllowed = Math.min(investmentAmount, taxableIncome * 0.25);
    return maxInvestmentAllowed * 0.15; // 15% of investment amount
  };

  const calculateTaxByBrackets = (amount: number): number => {
    let tax = 0;
    let remainingAmount = amount;

    for (const bracket of TAX_BRACKETS) {
      if (remainingAmount <= 0) break;

      const bracketAmount = bracket.max 
        ? Math.min(remainingAmount, bracket.max - bracket.min)
        : remainingAmount;

      tax += bracketAmount * bracket.rate;
      remainingAmount -= bracketAmount;
    }

    return tax;
  };

  useEffect(() => {
    const exemptedAmount = calculateExemptedIncome(income);
    const calculatedTaxableIncome = Math.max(0, income - exemptedAmount);
    setTaxableIncome(calculatedTaxableIncome);

    const calculatedTax = calculateTaxByBrackets(calculatedTaxableIncome);
    const investmentRebate = calculateInvestmentRebate(investment);
    
    let finalTax = Math.max(calculatedTax - investmentRebate, MINIMUM_TAX[location]);
    finalTax = Math.max(0, finalTax - sourceTax);
    
    setTotalTax(calculatedTax);
    setNetTaxPayable(finalTax);
  }, [income, category, location, investment, sourceTax]);

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center gap-3 mb-6">
        <Calculator className="w-8 h-8 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-800">Bangladesh Tax Calculator 2024-25</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Taxpayer Category
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={category}
              onChange={(e) => setCategory(e.target.value as TaxPayerCategory)}
            >
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="disabled">Disabled</option>
              <option value="freedomFighter">Freedom Fighter</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={location}
              onChange={(e) => setLocation(e.target.value as typeof location)}
            >
              <option value="dhaka_chittagong">Dhaka/Chittagong City</option>
              <option value="other_city">Other City Corporations</option>
              <option value="rest">Rest of the Country</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Total Income (BDT)
            </label>
            <input
              type="number"
              className="w-full p-2 border rounded-md"
              value={income}
              onChange={(e) => setIncome(Number(e.target.value))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Investment Amount (BDT)
            </label>
            <input
              type="number"
              className="w-full p-2 border rounded-md"
              value={investment}
              onChange={(e) => setInvestment(Number(e.target.value))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Source Tax/Advance Tax (BDT)
            </label>
            <input
              type="number"
              className="w-full p-2 border rounded-md"
              value={sourceTax}
              onChange={(e) => setSourceTax(Number(e.target.value))}
            />
          </div>
        </div>

        <div className="bg-gray-50 p-6 rounded-lg">
          <h2 className="text-xl font-semibold mb-4">Tax Calculation Summary</h2>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Income:</span>
              <span className="font-medium">BDT {income.toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600">Taxable Income:</span>
              <span className="font-medium">BDT {taxableIncome.toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600">Total Tax:</span>
              <span className="font-medium">BDT {totalTax.toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600">Investment Rebate:</span>
              <span className="font-medium">BDT {calculateInvestmentRebate(investment).toLocaleString()}</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-gray-600">Source/Advance Tax:</span>
              <span className="font-medium">BDT {sourceTax.toLocaleString()}</span>
            </div>
            
            <div className="border-t pt-3 mt-3">
              <div className="flex justify-between text-lg font-semibold">
                <span className="text-gray-800">Net Tax Payable:</span>
                <span className="text-blue-600">BDT {netTaxPayable.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 text-sm text-gray-500">
            <p className="font-medium mb-2">Tax Slabs (2024-25):</p>
            <ul className="space-y-1">
              {TAX_BRACKETS.map((bracket, index) => (
                <li key={index}>
                  {bracket.display}: {(bracket.rate * 100)}%
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-6 text-sm text-gray-500">
        <p><strong>Note:</strong> This calculator is for estimation purposes only. Please consult with a tax professional for accurate tax planning and filing.</p>
      </div>
    </div>
  );
};

export default TaxCalculator;