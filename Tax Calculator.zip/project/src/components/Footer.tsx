import React, { useEffect, useState } from 'react';
import { Heart, ArrowUp, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const currentYear = new Date().getFullYear();

  const toggleVisibility = () => {
    if (window.pageYOffset > 300) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  useEffect(() => {
    window.addEventListener('scroll', toggleVisibility);
    return () => {
      window.removeEventListener('scroll', toggleVisibility);
    };
  }, []);

  return (
    <footer className="relative mt-auto">
      <div className="border-t border-gray-200">
        <div className="bg-gradient-to-b from-white to-gray-50 py-8">
          <div className="container mx-auto px-4">
            <div className="flex flex-col items-center justify-center space-y-6">
              <div className="flex items-center justify-center space-x-6">
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" 
                   className="text-gray-600 hover:text-blue-600 transition-colors duration-300">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer"
                   className="text-gray-600 hover:text-blue-400 transition-colors duration-300">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"
                   className="text-gray-600 hover:text-pink-600 transition-colors duration-300">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
                   className="text-gray-600 hover:text-blue-700 transition-colors duration-300">
                  <Linkedin className="w-5 h-5" />
                </a>
              </div>
              
              <div className="text-center">
                <p className="text-gray-800 font-sans text-lg">
                  Made with{' '}
                  <span className="inline-flex items-center mx-1">
                    <Heart className="w-5 h-5 text-red-500 animate-pulse" />
                  </span>
                  {' '}in{' '}
                  <span className="text-green-600 font-serif font-semibold">Bangladesh</span>
                </p>
                <p className="mt-2 text-sm text-gray-600">
                  © {currentYear} Bangladesh Tax Calculator. All rights reserved.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={scrollToTop}
        className={`fixed bottom-8 right-8 bg-green-600 text-white p-2 rounded-full shadow-lg transition-opacity duration-300 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 ${
          isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <ArrowUp className="w-5 h-5" />
      </button>
    </footer>
  );
};

export default Footer;