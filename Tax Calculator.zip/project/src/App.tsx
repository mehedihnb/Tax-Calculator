import React from 'react';
import TaxCalculator from './components/TaxCalculator';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 py-8 flex flex-col">
      <TaxCalculator />
      <Footer />
    </div>
  );
}

export default App;